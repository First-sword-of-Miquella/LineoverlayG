package com.example.lineoverlay

import android.content.Context
import android.graphics.PointF

object Prefs {
    private const val NAME = "guide"

    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun saveCorners(c: Context, corners: List<PointF>) {
        sp(c).edit().putString("corners", encode(corners)).apply()
    }

    fun corners(c: Context): List<PointF> = decode(sp(c).getString("corners", "") ?: "")

    fun savePoint(c: Context, key: String, p: PointF) {
        sp(c).edit().putFloat(key + "_x", p.x).putFloat(key + "_y", p.y).apply()
    }

    fun point(c: Context, key: String): PointF? {
        val s = sp(c)
        if (!s.contains(key + "_x")) return null
        return PointF(s.getFloat(key + "_x", 0f), s.getFloat(key + "_y", 0f))
    }

    fun side(c: Context): Int = sp(c).getInt("side", 0)

    fun saveSide(c: Context, v: Int) {
        sp(c).edit().putInt("side", v).apply()
    }

    private fun encode(points: List<PointF>) = points.joinToString(";") { "${it.x},${it.y}" }

    private fun decode(s: String): List<PointF> = s.split(";").mapNotNull { a ->
        val p = a.split(",")
        if (p.size == 2) p[0].toFloatOrNull()?.let { x -> p[1].toFloatOrNull()?.let { y -> PointF(x, y) } } else null
    }
}
