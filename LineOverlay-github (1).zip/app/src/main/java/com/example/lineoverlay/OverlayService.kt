package com.example.lineoverlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.hypot

/**
 * Floating aim guide:
 *  - a ring (the cue ball position) that is NOT touchable, so it never blocks the ball
 *  - a red handle beside the ring: drag it to move the ring
 *  - a cyan handle: drag it anywhere to set the aim direction
 *  - two lines: the aim line to the first rail, and its bounce to the next rail
 *  - a draggable floating button that opens a small menu
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_CALIBRATE = "calibrate"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "guide"
        private const val NOTIF_ID = 10
        private const val BALL_FRAC = 0.0145f   // ball radius as a fraction of table width
    }

    private lateinit var wm: WindowManager
    private lateinit var canvas: GuideCanvas
    private lateinit var moveHandle: HandleView
    private lateinit var aimHandle: HandleView
    private lateinit var bubble: BubbleView
    private lateinit var canvasLp: WindowManager.LayoutParams
    private lateinit var moveLp: WindowManager.LayoutParams
    private lateinit var aimLp: WindowManager.LayoutParams
    private lateinit var bubbleLp: WindowManager.LayoutParams

    private var menu: MenuView? = null
    private var menuHiddenAt = 0L

    private var center = PointF()
    private var aim = PointF()
    private var corners: List<PointF> = emptyList()
    private var guideOn = true
    private var calibrating = false
    private var side = 0
    private val calPts = mutableListOf<PointF>()
    private val sides = arrayOf(intArrayOf(1, 1), intArrayOf(-1, 1), intArrayOf(-1, -1), intArrayOf(1, -1))

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(
            NOTIF_ID,
            NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Line Overlay Guide")
                .setContentText("Overlay is running")
                .setOngoing(true)
                .build()
        )
        corners = Prefs.corners(this)
        side = Prefs.side(this)
        loadGuide()

        canvas = GuideCanvas(this)
        moveHandle = HandleView(this, Color.rgb(235, 60, 60), true)
        aimHandle = HandleView(this, Color.rgb(40, 200, 235), false)
        bubble = BubbleView(this)

        canvasLp = params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, false)
        canvasLp.alpha = 0.8f   // Android 12+ blocks touches through overlays that are more opaque than this
        moveLp = params(dp(52), dp(52), true)
        aimLp = params(dp(52), dp(52), true)
        bubbleLp = params(dp(48), dp(48), true)
        val savedBubble = Prefs.point(this, "bubble")
        val dm = resources.displayMetrics
        bubbleLp.x = savedBubble?.x?.toInt() ?: (dm.widthPixels - dp(60))
        bubbleLp.y = savedBubble?.y?.toInt() ?: dp(90)

        wm.addView(canvas, canvasLp)
        wm.addView(moveHandle, moveLp)
        wm.addView(aimHandle, aimLp)
        wm.addView(bubble, bubbleLp)
        refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CALIBRATE -> startCalibration()
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val dm = resources.displayMetrics
        if (center.x > dm.widthPixels || center.y > dm.heightPixels) resetGuide(false) else refresh()
    }

    override fun onDestroy() {
        hideMenu()
        runCatching { wm.removeView(canvas) }
        runCatching { wm.removeView(moveHandle) }
        runCatching { wm.removeView(aimHandle) }
        runCatching { wm.removeView(bubble) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "Overlay", NotificationManager.IMPORTANCE_LOW))
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float): Float = v * resources.displayMetrics.density

    private fun params(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        flags = if (touchable) {
            flags or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        val p = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        // make every window use the same physical-screen origin, even with a camera cut-out
        if (Build.VERSION.SDK_INT >= 30) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    private fun defaultCenter(): PointF {
        val dm = resources.displayMetrics
        val r = Geometry.ballRect(corners, BALL_FRAC)
        return if (r != null) PointF(r.centerX(), r.centerY()) else PointF(dm.widthPixels / 2f, dm.heightPixels / 2f)
    }

    private fun loadGuide() {
        val dm = resources.displayMetrics
        val c = Prefs.point(this, "circle")
        val a = Prefs.point(this, "aim")
        if (c != null && c.x in 0f..dm.widthPixels.toFloat() && c.y in 0f..dm.heightPixels.toFloat()) {
            center = c
            aim = a ?: PointF(c.x + dp(180), c.y)
        } else {
            resetGuide(false)
        }
    }

    private fun resetGuide(persist: Boolean = true) {
        center = defaultCenter()
        aim = PointF(center.x + dp(180), center.y)
        if (persist) saveGuide()
        if (::canvas.isInitialized) refresh()
    }

    private fun saveGuide() {
        Prefs.savePoint(this, "circle", center)
        Prefs.savePoint(this, "aim", aim)
    }

    private fun moveHandlePos(): PointF {
        val s = sides[side]
        val d = dp(72)
        return PointF(center.x + s[0] * d, center.y + s[1] * d)
    }

    private fun placeHandles() {
        val half = dp(52) / 2
        val m = moveHandlePos()
        moveLp.x = (m.x - half).toInt()
        moveLp.y = (m.y - half).toInt()
        aimLp.x = (aim.x - half).toInt()
        aimLp.y = (aim.y - half).toInt()
        wm.updateViewLayout(moveHandle, moveLp)
        wm.updateViewLayout(aimHandle, aimLp)
    }

    private fun refresh() {
        val vis = if (guideOn && !calibrating) View.VISIBLE else View.GONE
        moveHandle.visibility = vis
        aimHandle.visibility = vis
        placeHandles()
        canvas.invalidate()
    }

    // ---------------------------------------------------------------- calibration

    private fun setCanvasTouchable(touchable: Boolean) {
        canvasLp.flags = if (touchable) {
            canvasLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            canvasLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        wm.updateViewLayout(canvas, canvasLp)
    }

    private fun startCalibration() {
        hideMenu()
        calibrating = true
        calPts.clear()
        setCanvasTouchable(true)
        refresh()
    }

    private fun cancelCalibration() {
        calibrating = false
        calPts.clear()
        setCanvasTouchable(false)
        refresh()
    }

    private fun undoCorner() {
        if (calPts.isNotEmpty()) calPts.removeAt(calPts.size - 1)
        canvas.invalidate()
    }

    private fun finishCalibration() {
        val list = ArrayList(calPts)
        if (Geometry.ballRect(list, BALL_FRAC) == null) {
            Toast.makeText(this, "Corners too close together, try again", Toast.LENGTH_SHORT).show()
            calPts.clear()
            canvas.invalidate()
            return
        }
        corners = list
        Prefs.saveCorners(this, corners)
        calPts.clear()
        calibrating = false
        setCanvasTouchable(false)
        resetGuide()
    }

    // ---------------------------------------------------------------- menu

    private fun onBubbleTap() {
        if (menu != null) {
            hideMenu()
            return
        }
        if (SystemClock.uptimeMillis() - menuHiddenAt < 350) return
        showMenu()
    }

    private fun addMenuItem(parent: LinearLayout, label: String, action: () -> Unit) {
        val t = TextView(this)
        t.text = label
        t.textSize = 16f
        t.setTextColor(Color.WHITE)
        t.setPadding(dp(16), dp(12), dp(16), dp(12))
        t.setOnClickListener {
            hideMenu()
            action()
        }
        parent.addView(t, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun showMenu() {
        if (menu != null) return
        val m = MenuView(this)
        m.orientation = LinearLayout.VERTICAL
        m.setPadding(dp(6), dp(6), dp(6), dp(6))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(235, 25, 25, 30))
        bg.cornerRadius = dpf(14f)
        bg.setStroke(dp(1), Color.argb(120, 255, 255, 255))
        m.background = bg

        if (calibrating) {
            addMenuItem(m, "Undo last corner") { undoCorner() }
            addMenuItem(m, "Cancel calibration") { cancelCalibration() }
        } else {
            addMenuItem(m, if (guideOn) "Hide guide" else "Show guide") {
                guideOn = !guideOn
                refresh()
            }
            addMenuItem(m, "Calibrate table") { startCalibration() }
            addMenuItem(m, "Reset guide") { resetGuide() }
            addMenuItem(m, "Move handle: other side") {
                side = (side + 1) % 4
                Prefs.saveSide(this, side)
                refresh()
            }
            addMenuItem(m, "Close overlay") { stopSelf() }
        }

        val w = dp(210)
        val lp = params(w, WindowManager.LayoutParams.WRAP_CONTENT, true)
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        val dm = resources.displayMetrics
        val onRight = bubbleLp.x > dm.widthPixels / 2
        lp.x = (if (onRight) bubbleLp.x - w - dp(8) else bubbleLp.x + dp(56)).coerceAtLeast(0)
        lp.y = bubbleLp.y.coerceIn(0, (dm.heightPixels - dp(280)).coerceAtLeast(0))
        wm.addView(m, lp)
        menu = m
    }

    private fun hideMenu() {
        val m = menu ?: return
        runCatching { wm.removeView(m) }
        menu = null
        menuHiddenAt = SystemClock.uptimeMillis()
    }

    // ---------------------------------------------------------------- views

    inner class MenuView(c: Context) : LinearLayout(c) {
        override fun dispatchTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                post { hideMenu() }
                return true
            }
            return super.dispatchTouchEvent(e)
        }
    }

    /** Full-screen, untouchable drawing layer (touchable only while calibrating). */
    inner class GuideCanvas(c: Context) : View(c) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        init {
            textPaint.textSize = dpf(14f)
            textPaint.typeface = Typeface.DEFAULT_BOLD
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (!calibrating) return false
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                calPts.add(PointF(e.rawX, e.rawY))
                if (calPts.size == 4) finishCalibration() else invalidate()
            }
            return true
        }

        override fun onDraw(c: Canvas) {
            if (calibrating) {
                drawCalibration(c)
                return
            }
            if (!guideOn) return

            val rect = Geometry.ballRect(corners, BALL_FRAC)
            val radius = Geometry.ballRadius(corners, BALL_FRAC).let { if (it > 2f) it else dpf(10f) }
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND

            // thin link between the ring and its red move handle
            val mh = moveHandlePos()
            paint.strokeWidth = dpf(1f)
            paint.color = Color.argb(120, 255, 90, 90)
            c.drawLine(center.x, center.y, mh.x, mh.y, paint)

            // the two aim lines: straight shot, then its bounce
            val pts = Geometry.aimPath(center, aim, rect)
            paint.strokeWidth = dpf(1.6f)
            for (i in 0 until pts.size - 1) {
                paint.color = if (i == 0) Color.argb(235, 255, 255, 255) else Color.argb(190, 120, 220, 255)
                c.drawLine(pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, paint)
            }

            // the ring itself
            paint.strokeWidth = dpf(1.5f)
            paint.color = Color.argb(210, 255, 255, 255)
            c.drawCircle(center.x, center.y, radius, paint)
        }

        private fun drawCalibration(c: Canvas) {
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(120, 0, 0, 0)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            paint.color = Color.rgb(255, 200, 0)
            for (p in calPts) c.drawCircle(p.x, p.y, dpf(7f), paint)
            paint.color = Color.WHITE
            c.drawRoundRect(dpf(16f), dpf(20f), width - dpf(16f), dpf(70f), dpf(12f), dpf(12f), paint)
            textPaint.color = Color.BLACK
            val names = arrayOf("top-left", "top-right", "bottom-right", "bottom-left")
            val i = calPts.size.coerceAtMost(3)
            c.drawText("Calibrate: tap inner cushion corner ${i + 1}/4 (${names[i]})", dpf(28f), dpf(51f), textPaint)
        }
    }

    /** Small dot with a big touch area. The red one moves the ring, the cyan one sets the aim. */
    inner class HandleView(c: Context, private val dotColor: Int, private val movesRing: Boolean) : View(c) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var downX = 0f
        private var downY = 0f
        private var startCenter = PointF()
        private var startAim = PointF()

        override fun onDraw(c: Canvas) {
            val x = width / 2f
            val y = height / 2f
            paint.style = Paint.Style.FILL
            paint.color = dotColor
            c.drawCircle(x, y, dpf(11f), paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dpf(1.5f)
            paint.color = Color.WHITE
            c.drawCircle(x, y, dpf(11f), paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startCenter = PointF(center.x, center.y)
                    startAim = PointF(aim.x, aim.y)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (movesRing) {
                        center = PointF(startCenter.x + dx, startCenter.y + dy)
                    }
                    // moving the ring carries the aim point along, so the direction is kept
                    aim = PointF(startAim.x + dx, startAim.y + dy)
                    placeHandles()
                    canvas.invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> saveGuide()
            }
            return true
        }
    }

    /** Draggable floating button; a tap opens the menu. */
    inner class BubbleView(c: Context) : TextView(c) {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var dragged = false
        private val slop = ViewConfiguration.get(c).scaledTouchSlop

        init {
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.argb(210, 20, 20, 20))
            bg.setStroke(dp(1), Color.argb(170, 230, 230, 230))
            background = bg
            text = "◎"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = bubbleLp.x
                    startY = bubbleLp.y
                    dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragged && hypot(dx, dy) > slop) dragged = true
                    if (dragged) {
                        bubbleLp.x = startX + dx.toInt()
                        bubbleLp.y = startY + dy.toInt()
                        wm.updateViewLayout(this, bubbleLp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        Prefs.savePoint(this@OverlayService, "bubble", PointF(bubbleLp.x.toFloat(), bubbleLp.y.toFloat()))
                    } else {
                        onBubbleTap()
                    }
                }
            }
            return true
        }
    }
}
