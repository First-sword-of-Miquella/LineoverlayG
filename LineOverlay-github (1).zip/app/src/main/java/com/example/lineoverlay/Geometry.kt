package com.example.lineoverlay

import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

object Geometry {

    /** Ball radius, estimated as a fraction of the calibrated table width. */
    fun ballRadius(corners: List<PointF>, frac: Float): Float {
        if (corners.size != 4) return 0f
        return (corners.maxOf { it.x } - corners.minOf { it.x }) * frac
    }

    /** Area where the ball CENTRE can travel: the calibrated table shrunk by one ball radius. */
    fun ballRect(corners: List<PointF>, frac: Float): RectF? {
        if (corners.size != 4) return null
        val r = ballRadius(corners, frac)
        val rect = RectF(
            corners.minOf { it.x } + r, corners.minOf { it.y } + r,
            corners.maxOf { it.x } - r, corners.maxOf { it.y } - r
        )
        return if (rect.width() > 20f && rect.height() > 20f) rect else null
    }

    /**
     * Aim line from [start] through [through], continued to the first rail, then bounced
     * once and continued to the next rail. Returns start, bounce 1, bounce 2 (two lines).
     * Without a calibrated [rect] it returns a single long straight line.
     */
    fun aimPath(start: PointF, through: PointF, rect: RectF?): List<PointF> {
        var dx = through.x - start.x
        var dy = through.y - start.y
        val len = hypot(dx, dy)
        if (len < 1f) return listOf(start)
        dx /= len
        dy /= len

        val inside = rect != null &&
            start.x >= rect.left && start.x <= rect.right &&
            start.y >= rect.top && start.y <= rect.bottom
        if (rect == null || !inside) {
            return listOf(start, PointF(start.x + dx * 4000f, start.y + dy * 4000f))
        }

        val pts = mutableListOf(start)
        var x = start.x
        var y = start.y
        repeat(2) {
            var tx = Float.MAX_VALUE
            var ty = Float.MAX_VALUE
            if (dx > 1e-6f) tx = (rect.right - x) / dx else if (dx < -1e-6f) tx = (rect.left - x) / dx
            if (dy > 1e-6f) ty = (rect.bottom - y) / dy else if (dy < -1e-6f) ty = (rect.top - y) / dy
            val t = max(0f, min(tx, ty))
            x += dx * t
            y += dy * t
            pts.add(PointF(x, y))
            if (tx < ty) dx = -dx else dy = -dy
        }
        return pts
    }
}
