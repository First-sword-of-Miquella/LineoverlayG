package com.example.lineoverlay

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(android.os.Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),1)
        val pad=(24*resources.displayMetrics.density).toInt()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(pad,pad,pad,pad)}
        root.addView(TextView(this).apply{text="Line Overlay Guide";textSize=26f;setPadding(0,0,0,pad/2)})
        root.addView(TextView(this).apply{text="1. Tap Calibrate table, then tap the 4 inner corners of the table.\n\n2. Drag the red dot to move the ring onto the cue ball. Drag the blue dot to aim: you get the aim line and its bounce.\n\nThe floating ◎ button (draggable) opens the menu: hide, calibrate, reset, switch handle side, close.";textSize=16f})
        root.addView(Button(this).apply{text="Start overlay";setOnClickListener{startOverlay(false)}})
        root.addView(Button(this).apply{text="Calibrate table";setOnClickListener{startOverlay(true)}})
        root.addView(Button(this).apply{text="Stop overlay";setOnClickListener{stopService(Intent(this@MainActivity,OverlayService::class.java))}})
        setContentView(root)
    }
    private fun startOverlay(calibrate:Boolean){
        if(!Settings.canDrawOverlays(this)){
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
            Toast.makeText(this,"Allow 'Display over other apps', then tap Calibrate again.",Toast.LENGTH_LONG).show(); return
        }
        ContextCompat.startForegroundService(this,Intent(this,OverlayService::class.java).apply{action=if(calibrate)OverlayService.ACTION_CALIBRATE else null})
        if(calibrate)Toast.makeText(this,"Return to the game. Calibration is ready.",Toast.LENGTH_SHORT).show()
    }
}
