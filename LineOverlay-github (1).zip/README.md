# Line Overlay Guide

Android floating aim ruler for pool-style games. Manual only: it never reads the screen.

## Use
1. Install the APK, open the app, grant **Display over other apps**.
2. Tap **Calibrate table** and tap the 4 inner cushion corners of the table in your game.
3. **Red dot** (next to the ring): drag it to move the ring onto the cue ball. The ring itself is not touchable, so it never blocks the ball.
4. **Blue dot**: drag it anywhere to set the aim. You get two lines: the aim line to the first rail, and its bounce to the next rail.
5. **Floating ◎ button** (draggable): tap for the menu: hide/show, calibrate, reset guide, switch red-dot side, close.

## Build
Push to `main` (or run the workflow manually) and download `line-overlay-apk` from the Actions run.
Requires JDK 17, Gradle 8.9, Android SDK 35.
